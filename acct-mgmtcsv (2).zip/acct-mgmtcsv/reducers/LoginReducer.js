//action constants
export const LOGIN = 'LOGIN';
export const SET_CLAIM_OBJ = 'SET_CLAIM_OBJ';
export const LOGOUT = 'LOGOUT';

const DEFAULT_STORE_OBJECT = {
    loggedInUser: null,
    claimObj: null
}

//define reducer
export const loginReducer = (state = DEFAULT_STORE_OBJECT, action) => {

    switch(action.type) {

        case LOGIN : 
            return {                
                loggedInUser: action.loggedInUser,
                claimObj: state.claimObj
            };
        case SET_CLAIM_OBJ: 
            return {
                claimObj: action.claimObj,
                loggedInUser: state.loggedInUser
            }
        case LOGOUT: 
        return {
            claimObj: null,
            loggedInUser: null
        }
                  
    }
    return DEFAULT_STORE_OBJECT;
}