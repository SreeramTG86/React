import React from 'react';




class App extends React.Component {
   
   
   render() {      
      let claimList = [{empId: 'AA-789999', empName: 'Ramesh', claimNumber:'ABC-123-ABC', claimType: 'Paid', claimProgram:'Maturity',claimStartDate: '2020-08-01', claimEndDate: '2020-08-05'}
                     ,{empId: 'BB-123456', empName: 'Suraj', claimNumber:'ABC-567-ABC', claimType: 'Pending', claimProgram:'Term',claimStartDate: '2020-08-10', claimEndDate: '2020-08-15'}
                     ]
      return (
         <div>
            {this.props.children}
        </div>
      );
   }
}

// const mapStateToProps = state => {
   
//    return {loggedInUser: state.loggedInUser}
// }

// const componentConnector = connect(mapStateToProps);

export default App;