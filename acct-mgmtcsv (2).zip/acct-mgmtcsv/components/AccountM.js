import React, { Component } from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import json2csv from "json2csv";
import { CSVLink, CSVDownload } from 'react-csv';
import SplitterLayout from 'react-splitter-layout';
import SplitPane, { Pane } from 'react-split-pane';
import { PDFDownloadLink,Document,Text,View,Page} from "@react-pdf/renderer";


class AccountM extends Component {
  constructor(props){
    super(props)
    this.state={

    }
  }
  // jsPdfGenerator=()=>{
  //   var doc =new jsPDF('p','pt');

  //   doc.save("generated.pdf");
  // }

    render() {
      const MyDoc = (
        <Document>
            <Page>
                <View>
                    <Text>account: 142121212</Text>
                </View>
                <View>
                    <Text> accountOwnerName: 'DONAROMISE'</Text>
                </View>
                <View>
                    <Text> accountOwnerName: 'DONAROMISE'</Text>
                </View>
            </Page>
        </Document>
    );
    const MyDocvalues = (
      <Document>
          <Page>
              <View>
                  <Text> fundId: 142</Text>
              </View>
              <View>
                  <Text>  fundName: 'PACIFIC FUNDS PORT OP MOD_CONS'</Text>
              </View>
              <View>
                  <Text> totalShares: 837.069</Text>
              </View>
          </Page>
      </Document>
  );

        const accountValues = [
            {
                fundId: 142,
                fundName: 'PACIFIC FUNDS PORT OP MOD_CONS',
                costBasis: 'AVERAGE COST',
                totalShares: 837.069,
                sharePrice: 10.79,
                totalDollars: 9031.97
            },
            {
                fundId: 342,
                fundName: 'PACIFIC FUNDS PORT OP MOD_CONS',
                costBasis: 'AVERAGE COST',
                totalShares: 330.579,
                sharePrice: 10.53,
                totalDollars: 3481.00
            }

        ]
        const accountlistValues = [
          {
            account: 142121212,
            accountOwnerName: 'DONAROMISE',
            eDeliv: 'N',
            eStamt: 'Stmt',
            planType: 'REGULAR ACCOUNT',
            values: '12.512.97'
          },
          {
            account: 142121223,
            accountOwnerName: 'DONAAS ROMISE',
            eDeliv: 'N',
            eStamt: 'Stmt',
            planType: 'REGULAR ACCOUNT',
            values: '12.512.97'
          },

      ]
        const rowStyle2 = (row, rowIndex) => {
            const style = {};
            if (rowIndex % 2 == 0) {
              style.backgroundColor = '#d3d3d3';

            } else {
              style.backgroundColor = '#808080';
              style.color = 'white';
            }
            return style;
        };

        const rowStyle3 = (row, rowIndex) => {
          const style = {};
          if (rowIndex % 2 == 0) {
            style.backgroundColor = 'lightblue';

          } else {
            style.backgroundColor = '#808080';
            style.color = 'white';
          }
          return style;
      };

        const columns = [{
            text: 'Fund #',
            dataField: 'fundId'
          }, {
            text: 'Fund Name',
            dataField: 'fundName'
          }, {
            text: 'Cost Basis Method',
            dataField: 'costBasis'
          },
          {
            text: 'Total Shares',
            dataField: 'totalShares'
          },
          {
            text: 'Share Price',
            dataField: 'sharePrice'
          },
          {
            text: 'Total Dollars',
            dataField: 'totalDollars'
          }
         ];

         const columnsList = [{
          text: 'Account',
          dataField: 'account'
        }, {
          text: 'Account Owner Name',
          dataField: 'accountOwnerName'
        }, {
          text: 'eDeliv',
          dataField: 'eDeliv'
        },
        {
          text: 'eStamt',
          dataField: 'eStamt'
        },
        {
          text: 'Plan Type',
          dataField: 'planType'
        },
        {
          text: 'Values',
          dataField: 'values'
        }
       ];
        return (

            <div>
                 <SplitPane split="vertical">
              <div >
            <select id="transactions" name="transactions">
                <option value="grouptransactions" selected="selected">--Group transactions--</option>
                <option value="singletransactions" selected="selected">--Single transactions--</option>
              </select>
              <select id="downloads" name="downloads" style={{float:'right'}}>
                <option value="downloads" selected="selected">--Downloads--</option>
                <option value="downloads2">--Downloads2--</option>
              </select>
            <br/>

            <BootstrapTable keyField='accountlistId' data={ accountlistValues } columns={ columnsList } rowStyle={ rowStyle3 }  pagination={ paginationFactory() } >


            </BootstrapTable>
            
       

            <CSVLink data={accountlistValues} filename="accountlist.csv">Download Account List as CSV</CSVLink>;
            <PDFDownloadLink  document={
           MyDoc }
          fileName="accountlist.pdf">generatepdf</PDFDownloadLink>
            </div>

            <div >
                <div className='blueBanner'>Acc#: 100211736 &emsp;<span>Owner: DONNA PRIMROSE</span></div>
                <br/>
                <div className='darkBlueBanner'>Account Information &emsp; Print</div>
                <br/>
                <div className='blueHeading'>Account Values </div>
                <div className='accountDiv'>
                    <div>Pacific Funds - REGULAR ACCOUNT</div>
                    <div className='inlineDiv'><div>Account Number</div><div>100211736</div></div>
                    <div className='inlineDiv'><div>Account Registration</div><div>DONNA PRIMROSE</div></div>
                    <div className='inlineDiv'><div>Open Date</div><div>09/02/2020</div></div>
                    <div className='inlineDiv'><div>Representative of Record</div><div>ALLEN ROSSEN</div></div>
                    <div className='inlineDiv'><div><a href='#'>eDelivery</a></div><div>No</div></div>
                </div>
                <br/>

                <BootstrapTable keyField='fundId' data={ accountValues } columns={ columns } rowStyle={ rowStyle2 } />

                <CSVLink data={accountValues} filename="AccountDetail.csv">Download Account Detail as CSV</CSVLink>;
                <PDFDownloadLink document={MyDocvalues}
             
          fileName="AccountDetail.pdf">generatepdf</PDFDownloadLink> 

            </div>
            </SplitPane>
            </div>

        );
    }
}

export default AccountM;