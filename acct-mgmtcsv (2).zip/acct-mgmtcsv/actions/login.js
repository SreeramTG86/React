import axios from 'axios';
import {LOGOUT, LOGIN} from '../reducers/LoginReducer';

export const logoutAction = () => {
    console.log('action: logout');
    return {
        type: LOGOUT,
        loggedInUser: null
    }
}

export const loginAction = userId => {
    console.log('action: loginAction');
    return {
        type: LOGIN,
        loggedInUser: userId
    }
}

export const doLogin = (dispatch) => {
    console.log('inside action.doLogin', dispatch);

    let userId = 'admin';
    let password = '123';
    console.log(userId, password);

    axios.get(`http://localhost:7001/users/`)
    .then(res => {

        let foundUser = false;
        for(let i=0;i < res.data.length; i++) {
            if(res.data[i].userId === userId
            && res.data[i].password === password) {
                console.log('userid/password is matching');
                foundUser = true;
            }
        }
        console.log('found matching User', foundUser);
        if(foundUser) {
            dispatch(loginAction(userId));            
        }
        // else {
        //     this.setState({invalidUser: true});
        // }
    }).catch(error => {
        console.log('error in authenticating...')
        //this.setState({invalidUser: true})
    })
}