
export const setClaimObjAction = (thisClaim) => {

    return {type: 'SET_CLAIM_OBJ', claimObj: thisClaim};
}
