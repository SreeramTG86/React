import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, browserHistory,IndexRoute } from 'react-router';
import thunk from 'redux-thunk';
import {createStore, applyMiddleware, compose} from 'redux';
import {Provider} from 'react-redux';

import {loginReducer} from './reducers/LoginReducer';
import App from './components/App';
import AccountM from './components/AccountM';


//create store
const store = createStore(loginReducer, 
    compose(
        applyMiddleware(thunk),
        window.devToolsExtension ? window.devToolsExtension() : f => f
      ));


//subscribe to dispatch method
store.subscribe(() => {
    console.log('dispatch called on store', store.getState());
})

ReactDOM.render(
    <Provider store={store}>
    <Router history = {browserHistory}>
        <Route path = "/" component = {App}>
            
            <IndexRoute component = {AccountM} />             
        </Route>
    </Router>
    </Provider>   
, document.getElementById('app'));